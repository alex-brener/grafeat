# Challenge Curator --- Claude Design Brief

**Status:** Validation prototype\
**Audience:** Claude Design\
**Working name:** Challenge Curator\
**Primary platform:** Web, desktop-first and responsive\
**Prototype goal:** Make Instagram challenge organizers understand and
experience the value of the product within 60--90 seconds, then capture
qualified interest and workflow feedback.

------------------------------------------------------------------------

## 1. Product premise

Challenge Curator is a focused workspace for organizers of recurring
Instagram challenges: calligraphy, lettering, typography, illustration,
drawing, photography, crafts, and similar visual communities.

These organizers already know how to create a challenge, publish
prompts, and attract participants. The repetitive operational burden
begins after participants start posting.

A typical daily workflow is:

**find submissions → check eligibility → sort by day → review →
shortlist → verify finalists → order selections → credit creators →
compose feature → publish**

The product should make this feel like:

> "I opened the app and today's submissions were already organized for
> me."

This is **not** intended to be a generic social-media-management suite,
giveaway platform, social wall, or UGC commerce platform.

### Core job to be done

> When participants submit work to my recurring Instagram challenge,
> help me quickly find and validate the correct entries, choose the best
> ones, and turn my selection into a properly credited Instagram feature
> without manually tracking everything.

### Primary promise

**From hundreds of challenge submissions to today's curated feature in
minutes.**

------------------------------------------------------------------------

## 2. Validation objective

This prototype is primarily a **market-research instrument**.

It should answer:

1.  Do challenge organizers immediately recognize the workflow?
2.  Does automatic collection and eligibility checking solve a
    meaningful problem?
3.  Is daily curation sufficiently painful to motivate adoption?
4.  Does the "select → reorder → auto-credit → publish" workflow create
    a strong enough "I want this" reaction?
5.  Will organizers volunteer their real challenge/account for beta
    testing?
6.  What parts of their actual workflow differ from our assumptions?

Do **not** optimize the design around maximizing generic waitlist
conversion at the expense of learning.

The strongest validation event is not an email address. It is an
organizer saying:

> "I want to try this with my actual challenge."

------------------------------------------------------------------------

## 3. Target users

### Primary persona

Organizer or small team running a recurring creative challenge primarily
through Instagram.

Typical categories:

-   calligraphy
-   lettering
-   typography
-   illustration
-   drawing
-   photography
-   crafts
-   design
-   maker communities

### Typical characteristics

-   challenge runs for 7--36+ days
-   often annual or seasonal
-   each day has a prompt, theme, letter, number, technique, or task
-   participants post to their own Instagram accounts
-   submissions use a challenge hashtag
-   participants tag/mention the official challenge account
-   some challenges also use a day-specific hashtag
-   organizer manually reviews submissions
-   a small number of entries are featured by the official challenge
    account
-   featured creators must be correctly credited
-   organizer repeats this workflow every day during the active
    challenge

### Secondary personas

-   art/craft brands running community challenges
-   organizations running creative participation campaigns
-   agencies/community managers operating challenges for clients
-   creators running several recurring community projects

------------------------------------------------------------------------

## 4. Real-world workflow patterns

The product concept is based on observed challenge patterns, not an
invented SaaS workflow.

Common examples include:

-   daily prompt
-   challenge-wide hashtag
-   daily hashtag
-   @mention/tag of challenge account
-   submission during a specific date/window
-   organizer reviews eligible work
-   4--10 favorite creators selected
-   selected works republished as a daily feature
-   creators credited in the caption
-   process repeats next day

The design should feel purpose-built for this exact ritual.

------------------------------------------------------------------------

## 5. Product model

Use the following conceptual model:

**Project / Challenge** → **Days / Prompts** → **Submissions** →
**Eligibility** → **Selection** → **Feature** → **Publish**

### Project / Challenge

Contains reusable settings:

-   name
-   challenge Instagram account
-   start/end date
-   challenge-wide hashtags
-   whether @mention is required
-   allowed media types
-   daily prompts
-   daily hashtags
-   maximum featured submissions
-   follower-verification mode
-   caption template
-   Reel/video audio handling
-   participation/republication disclaimer
-   publishing settings

### Challenge Day

Examples:

-   Day 14 --- Contrast
-   Day 15 --- Motion
-   Day 16 --- Rhythm
-   Day 17 --- Texture

Each day may inherit project rules and add:

-   prompt/title
-   date
-   day-specific hashtag

### Submission

A detected Instagram post or Reel that potentially belongs to the
challenge.

Relevant information:

-   media
-   creator username
-   timestamp
-   caption
-   media type
-   challenge mention status
-   required hashtag status
-   daily hashtag status
-   date validity
-   eligibility status
-   reason(s) for review/rejection
-   selected/not selected

------------------------------------------------------------------------

## 6. Known technical/product constraints

Treat these as real constraints. Do not design functionality that
implies capabilities we do not expect to have.

### Instagram participation

The challenge account is explicitly **@mentioned/tagged** by
participants. This is already an official rule for the initial
real-world use case.

The system may also check:

-   challenge-wide hashtags
-   day-specific hashtags
-   posting date/window
-   media type

### Follower verification

The system **cannot automatically verify whether a participant follows
the challenge account** through the official Instagram API.

Therefore:

-   follower verification is manual
-   it should occur only for shortlisted/final selected creators
-   UI may provide an action to open the creator's Instagram profile
-   organizer can manually mark the creator as verified

Do not imply automated follower verification.

### Reels/video

Selected video may need audio removed before being republished.

The desired product behavior is:

-   detect/show that selected media is video/Reel
-   offer **Keep audio / Remove audio** where technically applicable
-   default may be configurable at project level
-   removing audio is a media-processing operation

For the validation prototype, this interaction can be simulated.

### Republished media

A curated carousel is a **new Instagram carousel using selected
creators' media**, not an embedded collection of existing Instagram
posts.

### Rights/disclaimer

The SaaS does not need a complex UGC rights-management system for MVP.

The organizer is responsible for having appropriate challenge
terms/permission to republish participant content. Product settings can
contain participation/republication disclaimer text.

------------------------------------------------------------------------

## 7. Primary experience to design

The most important experience is a single daily curation session.

Use this concrete scenario.

### Demo project

**Creative October 2026**

Instagram account:

`@creativeoctober`

Duration:

October 1--31, 2026

Current day:

**Day 16 --- Rhythm**

Required participation rules:

-   mention/tag `@creativeoctober`
-   use `#creativeoctober26`
-   use `#creativeoctober26rhythm`
-   post within the Day 16 submission window
-   image or Reel/video accepted
-   follow `@creativeoctober` --- manually verified only for selected
    finalists

Maximum featured:

**10**

Default video setting:

**Remove audio before republishing**

### Today's incoming data

**184 submissions**

Suggested distribution:

-   **151 Eligible**
-   **21 Missing daily hashtag**
-   **7 Wrong date**
-   **5 Need review**

The exact presentation of these states is a UX problem for Claude
Design. Do not assume they must be cards, tabs, badges, or any
particular control.

------------------------------------------------------------------------

## 8. Primary user journey

The prototype must make the following workflow understandable and
preferably interactive.

### A. Open today's challenge day

Organizer lands in the project and immediately understands:

-   which day/prompt is active
-   how many submissions arrived
-   how many are eligible
-   how many need attention
-   whether there are unresolved problems

### B. Review submissions

Artwork/media should dominate the experience.

Organizer must be able to:

-   browse submissions quickly
-   distinguish eligible entries from problematic ones
-   understand why an entry failed validation
-   filter or otherwise focus on eligible work
-   inspect creator/caption details when necessary
-   handle posts and Reels/videos

Avoid making the experience resemble an enterprise moderation console.

### C. Select finalists

Organizer selects up to 10 entries.

The UI should make it effortless to understand:

-   what is selected
-   current count
-   maximum allowed
-   selected order, where relevant

Selection should feel fast and satisfying.

### D. Manually verify follower requirement

Only selected/final entries need follower verification.

For each selected creator:

-   show verification state
-   provide **Open Instagram profile**
-   allow organizer to mark **Verified**

The product should make this feel like a small final check, not a major
workflow.

### E. Create feature

Selected media becomes a proposed Instagram carousel.

Organizer must be able to:

-   preview the carousel
-   reorder selected creators/media
-   see numbering update
-   see creator-credit order update automatically
-   remove an item
-   potentially add another item before finalizing

### F. Handle video audio

For a video/Reel:

-   identify it clearly as video
-   show audio state
-   allow Keep / Remove Audio where appropriate
-   show that the choice will apply to publication output

### G. Generate/edit caption

Caption is based on a project template.

Example:

> Day 16 --- Rhythm ✨
>
> Another beautiful day of Creative October.
>
> Today's featured artists:
>
> 1.  @maya_letters\
> 2.  @anna_draws\
> 3.  @johnillustrates\
> 4.  @studio_lina\
> 5.  @markdraws
>
> Thank you everyone for participating!
>
> #creativeoctober26 #creativeoctober26rhythm

Requirements:

-   fully editable
-   numbered creator list follows carousel order automatically
-   required challenge hashtags can be surfaced/validated
-   creator-credit completeness can be surfaced
-   changes in ordering should visibly affect both carousel and credits

This reorder/credit relationship is an important potential "wow"
interaction.

### H. Publish

Show a final Instagram-like preview.

Possible actions:

-   Publish now
-   Schedule

For validation, publication is simulated.

After simulated publishing, show a restrained success state.

Possible information:

-   number of creators featured
-   day/prompt
-   completion status
-   optional estimated time saved

Do not make unsupported quantitative claims appear factual. Any
time-saved number in the prototype must clearly be an estimate.

------------------------------------------------------------------------

## 9. Secondary product screens

The interactive demo does not need every screen to be equally deep, but
the design should establish that this is reusable SaaS rather than a
one-off tool.

### Projects / Challenges

Example projects:

**Creative October 2026**\
Oct 1--31\
Active · Day 16/31

**Lettering May 2026**\
May 1--31\
Completed

**Creative October 2025**\
Oct 1--31\
Completed

Required concept:

**Duplicate challenge**

Duplication should suggest that reusable settings, rules,
prompts/templates, and publishing configuration can be inherited for
next year/season.

### Project settings

Need a believable design for:

#### General

-   challenge name
-   Instagram account
-   dates

#### Submission rules

-   required @mention
-   challenge hashtag(s)
-   allowed media
-   submission timing

#### Daily prompts

Example table/list: - Oct 14 --- Contrast ---
`#creativeoctober26contrast` - Oct 15 --- Motion ---
`#creativeoctober26motion` - Oct 16 --- Rhythm ---
`#creativeoctober26rhythm` - Oct 17 --- Texture ---
`#creativeoctober26texture`

#### Selection

-   max featured: 10
-   follower verification: Manual

#### Publishing

-   caption template
-   default video audio behavior
-   challenge hashtags
-   publication settings

#### Participation / rights

-   disclaimer/terms text

------------------------------------------------------------------------

## 10. Marketing landing page

The marketing page and product UI should be related but not visually
identical.

### Desired narrative

The visitor should understand:

1.  the daily pain
2.  that submissions are automatically organized
3.  that rules are automatically checked
4.  that curation remains human
5.  that the repetitive production work is automated
6.  that the challenge can be reused next season/year
7.  that the product is purpose-built for challenge organizers

### Hero direction

Working copy:

# Curate your Instagram challenge.

# Not your spreadsheets.

Automatically collect and validate challenge submissions. Pick your
favorites and turn them into a credited Instagram carousel --- in
minutes.

Primary CTA:

**Try the interactive demo**

Secondary CTA:

**I run a challenge**

Do not treat this copy as sacred. Claude Design may propose
hierarchy/copy improvements, but preserve the positioning.

### Core concept line

**Collect → Validate → Curate → Credit → Publish**

### Product demonstration

The product should appear very early on the page.

Avoid a long marketing preamble before visitors see the workflow.

The dashboard/product is the strongest selling asset.

------------------------------------------------------------------------

## 11. Interactive validation demo

The marketing page should contain or lead directly into a realistic
product simulation.

The visitor should be able to experience enough of the workflow to
understand the product without needing a video.

Minimum useful interactions:

-   open/focus today's submissions
-   view eligibility state
-   filter/focus on eligible submissions
-   select several works
-   see selection count
-   proceed to feature creation
-   reorder selected creators/media
-   see creator-credit numbering/order update
-   edit caption
-   interact with manual verification
-   interact with video audio choice
-   simulate publishing

The demo does **not** need a real backend or Instagram connection.

It should feel believable, not like a clickable slide deck.

------------------------------------------------------------------------

## 12. Validation CTA

After the visitor understands/uses the demo, ask for qualified interest.

Working section:

### Run an Instagram challenge?

We're building this for challenge organizers. Tell us how you currently
curate submissions and get early access.

Suggested fields:

-   Instagram challenge/account
-   email
-   challenge frequency:
    -   Once a year
    -   Several times a year
    -   Always running / continuous
-   free-text question:

**What's the most time-consuming part of running your challenge today?**

Primary action:

**Get early access**

The CTA should feel like access to a relevant beta/research program, not
a generic newsletter signup.

------------------------------------------------------------------------

## 13. Realistic fixture submissions

Do not use Lorem Ipsum or `@user123`.

Create a believable creative community.

Suggested creators:

-   `@maya_letters`
-   `@anna_draws`
-   `@johnillustrates`
-   `@studio_lina`
-   `@markdraws`
-   `@inkandmoss`
-   `@sophiecreates`
-   `@paperandform`
-   `@nora_sketches`
-   `@typebyjules`
-   `@line.and.light`
-   `@marco_ink`
-   `@littlebrushstudio`
-   `@madebyines`
-   `@thequietpen`

Use varied media:

-   calligraphy
-   lettering
-   illustration
-   abstract ink
-   photography
-   collage
-   typography
-   sketching
-   one or more video/Reel entries

Use believable validation failures:

### Eligible

Mention ✓\
Challenge hashtag ✓\
Daily hashtag ✓\
Date ✓

### Missing daily hashtag

Mention ✓\
Challenge hashtag ✓\
Daily hashtag ✕\
Date ✓

### Wrong date

Mention ✓\
Challenge hashtag ✓\
Daily hashtag ✓\
Date ✕

### Needs review

Example ambiguity such as caption/edit state or another rule requiring
human judgment.

The exact visual representation is intentionally unspecified.

------------------------------------------------------------------------

## 14. Design direction

### Desired character

**Editorial / gallery / creative tool × calm productivity software**

The submitted artwork supplies much of the visual richness.

The surrounding UI should be restrained.

Desired qualities:

-   sophisticated
-   calm
-   highly legible
-   visual
-   contemporary
-   creative without being childish
-   professional without feeling enterprise-heavy
-   generous whitespace
-   strong image presentation
-   clear hierarchy
-   subtle states
-   low cognitive load

### Avoid

-   neon "creator economy" aesthetic
-   crypto/startup visual clichés
-   excessive gradients
-   generic social-media-dashboard density
-   gamification
-   enterprise moderation-table aesthetic
-   Instagram visual imitation everywhere
-   excessive card-within-card layouts
-   unnecessary charts
-   dashboards filled with vanity metrics

### Product UI principle

**Artwork first. Interface second.**

The user is judging creative submissions. The software should get out of
the way.

### Marketing UI principle

The landing page may have more personality and storytelling than the
application itself, while still feeling like the same brand.

------------------------------------------------------------------------

## 15. Responsive behavior

Desktop is primary because curation and carousel composition benefit
from screen space.

However:

-   landing page must work well on mobile
-   submission browsing should remain usable on tablet/mobile
-   selected-count/action state must remain visible
-   composer can simplify on smaller screens
-   do not design interactions that fundamentally require hover

The validation prototype does not need a perfect mobile production
workflow, but it should not visually break.

------------------------------------------------------------------------

## 16. Implementation constraints

The eventual validation prototype will likely be implemented as a small
**Next.js / React** application using fixture data.

Design accordingly:

-   avoid interactions requiring complex canvas/rendering technology
    unless they create exceptional value
-   use implementable web patterns
-   avoid unnecessary animation complexity
-   interactions should be reproducible by an AI coding assistant
-   no backend is required for the validation prototype
-   no real Instagram API is required for the validation prototype
-   simulated state is acceptable
-   architecture should not dictate the design, but implementation
    should be realistic

The first coded prototype should ideally be buildable in approximately
one focused day once design is sufficiently resolved.

------------------------------------------------------------------------

## 17. What Claude Design should solve

Do not merely execute presumed UI patterns. Explore and recommend
solutions for these questions.

### Submission overview

What is the clearest way to communicate:

-   184 total
-   151 eligible
-   33 requiring attention
-   why entries are invalid

without making the product feel like an enterprise moderation system?

### Gallery

How much eligibility information belongs directly on artwork versus on
hover/tap/detail?

### Selection

What is the fastest and clearest way to select up to 10 pieces while
preserving focus on the artwork?

### Selected state

Should selections be represented only in-grid, in a tray, side panel,
bottom bar, or another mechanism?

### Composer

What is the best relationship between:

-   carousel preview
-   selected/reorderable creators
-   manual follower verification
-   video/audio status
-   editable caption

without overloading one screen?

### Instagram resemblance

How much should the publication preview resemble Instagram, versus
remaining clearly part of Challenge Curator?

### Landing page → demo

Should the demo be:

-   embedded directly in the page
-   opened into a focused full-screen product simulation
-   partially embedded and then expanded

Recommend the strongest validation experience.

### Projects

How much of project management should be shown on the marketing/demo
path before it distracts from the core daily workflow?

------------------------------------------------------------------------

## 18. What Claude Design should NOT decide

These are product constraints unless a serious UX/product contradiction
is found:

-   @mention is a valid/expected participation requirement
-   follower verification is manual
-   maximum Instagram carousel size is 10
-   creator credits should follow selected media order
-   projects/challenges can be duplicated
-   rules/settings live at project level with daily overrides where
    appropriate
-   selected video may have audio removed
-   rights-management automation is out of MVP scope
-   product is not a general-purpose social scheduler
-   product is not a giveaway winner picker

If a constraint creates a major UX issue, flag it rather than silently
redesigning the product premise.

------------------------------------------------------------------------

## 19. Suggested screens / artifacts to produce

Please explore the system coherently rather than creating disconnected
mockups.

At minimum produce design direction for:

1.  Marketing landing page / hero
2.  Interactive demo entry
3.  Today / Challenge Day submission view
4.  Submission detail or expanded state if needed
5.  Selected/finalist workflow
6.  Feature / carousel composer
7.  Manual follower verification interaction
8.  Video audio state/control
9.  Publish preview and success state
10. Projects / Challenges view
11. Project Settings
12. Daily Prompts configuration
13. Early-access / research CTA
14. Mobile/responsive treatment of the most important marketing and
    product states

If appropriate, combine screens rather than creating unnecessary routes.

------------------------------------------------------------------------

## 20. Prototype success test

A qualified challenge organizer seeing the prototype for the first time
should be able to answer the following after approximately 60--90
seconds:

-   What does this product do?
-   Is it meant for someone like me?
-   How does it know which submissions belong to today?
-   What happens to invalid submissions?
-   Do I still choose the featured work myself?
-   Can I feature several creators in one carousel?
-   Will it credit creators in the correct order?
-   What happens with follower verification?
-   Can I reuse the challenge next year?
-   What would I do next if I wanted to try it?

If the interface requires explanatory narration to answer most of these,
simplify it.

------------------------------------------------------------------------

## 21. Desired emotional response

The key reaction is not:

> "This looks powerful."

It is:

> **"Oh --- this would save me from doing that every day."**

Secondary reaction:

> **"I still control the creative selection; it just removes the boring
> work."**

The product should preserve the organizer's role as curator. Automation
handles organization and repetitive production, not artistic judgment.

------------------------------------------------------------------------

## 22. Design output request

Please:

1.  Review the workflow critically before designing.
2.  Flag any UX contradictions or missing states.
3.  Propose an information architecture.
4.  Establish a coherent visual/design-system direction.
5.  Design the core daily workflow first.
6.  Design the marketing page around the actual product experience
    second.
7.  Use realistic fixture data and artwork/media placeholders.
8.  Make the interactive validation path obvious.
9.  Explain major UX decisions where alternatives were plausible.
10. Keep implementation realistic for a lightweight Next.js validation
    prototype.

Do **not** add features merely to make the product appear more complete.

The goal is to discover whether the core workflow is compelling enough
to deserve a real SaaS build.
