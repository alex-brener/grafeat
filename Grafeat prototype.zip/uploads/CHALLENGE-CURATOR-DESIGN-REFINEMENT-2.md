# Challenge Curator --- Design Refinement 2

Keep the current design direction and information architecture. This is
a focused refinement, not a redesign.

We've reviewed the prototype and want to simplify it further around the
core principle: **Challenge Curator should remove administrative work,
not give organizers more edge cases to manage.**

## 1. Reduce demo/tutorial chrome

The persistent three-step instructions above the application make the
experience feel slightly like a guided prototype.

Explore a subtler treatment: contextual guidance when useful,
progressive hints, or another lightweight solution. The **Curate →
Compose → Publish** navigation itself is good and should remain.

## 2. Simplify submission states

The four counters currently behave as navigation, but this isn't
visually obvious.

More importantly, reconsider the importance of **Need your call**.

Our desired default philosophy is:

-   **Ready to curate** --- submissions that satisfy the rules. This is
    where the organizer should spend almost all their time.
-   **Set aside automatically** --- submissions that fail deterministic
    rules. They are not deleted and can still be inspected/reinstated if
    the organizer deliberately wants to, but there should be no
    expectation that the organizer reviews them.
-   **Need your call** --- minimize or potentially remove this state
    from the primary workflow.

Participants are responsible for following challenge rules. The product
should not create work for the organizer by asking them to resolve
misspelled hashtags, wrong dates, duplicate submissions, etc.

Please explore whether the primary Curate experience can essentially be:

**Collected → Ready to curate / Set aside**

with exceptional cases accessible but not demanding attention.

Also make it visually obvious that the summary states are interactive
filters/navigation if they remain clickable.

## 3. Simplify follower verification in Compose

The current functionality is correct, but explore a lighter UI.

Instead of a large **Open profile** button, make the creator handle
itself clickable, e.g. `@paperandform ↗`, opening Instagram.

Then use compact text actions/status such as:

**Verify** / **Skip**

or another similarly lightweight treatment.

Important semantic distinction:

The system should store **Verified**, not **Follows**.

"Verified" means the organizer has manually completed whatever follower
check they consider necessary. Challenge Curator should not claim to
know whether the creator follows the account.

Once a creator has been manually verified for this challenge/account,
store that state so they do **not need to be manually checked again on
subsequent challenge days**.

Show previously verified creators automatically as something like:

**✓ Verified previously**

with an option to change/reset it if necessary.

## 4. Follower verification must not hard-block publishing

An unverified finalist should generate a warning, not disable
publishing.

For example:

**⚠ 1 creator hasn't been verified**

Actions:

**Review** / **Publish anyway**

The organizer remains in control.

## 5. Redesign challenge/day hashtag configuration

Do **not** automatically rename arbitrary hashtags when duplicating a
challenge.

Also remove the assumption that daily hashtags should be based on the
daily prompt. Prompts may be long phrases and often change completely
every year.

Instead, challenge hashtags should support **templates**.

For example:

Challenge-wide:

`#[challengename][YYYY]`

→ `#creativeoctober2026`

Daily:

`#[challengename][YYYY]_day[DD]`

→ `#creativeoctober2026_day16`

The exact token syntax can be improved, but the principle is:

**stable template + generated year/day values**

This minimizes setup work and dramatically reduces typo risk.

When duplicating a challenge for a new year, the template stays the same
and generated hashtags automatically use the new year.

Show the organizer a preview of generated hashtags rather than asking
them to enter every day's hashtag manually.

## 6. Remove daily prompts as a required V1 setup task

Many challenge organizers already create and publish one image
containing the full month's prompts.

We should not force them to duplicate those 31 prompts inside Challenge
Curator just to operate the challenge.

For V1, the product can organize submissions simply by:

**Day 01, Day 02 ... Day 31**

and their corresponding dates/generated hashtags.

A prompt/title such as "Rhythm" may remain optional if useful, but it
should not be required.

Do not make "enter all prompts" part of the core onboarding/settings
workflow.

A future version could provide dedicated prompt management and even
generate the challenge's prompt-list artwork, but that is explicitly
outside the current validation prototype.

For the current demo, keeping "Rhythm" as illustrative fixture content
is fine, but the interface should not imply that entering prompts is
necessary.

## 7. Keep the current application typography

No need to explore reduced serif usage.

The current balance---one expressive serif page title with restrained
sans-serif application UI---works well.

Keep the existing editorial visual direction.

## 8. Refine the hero message

Replace the spreadsheet-specific positioning.

Preferred direction:

**Your challenge deserves curation.\
Not administration.**

The distinction we want to communicate is:

**human creative judgment / curation vs repetitive administrative
work.**

Please refine the supporting copy around that idea while preserving the
current clear explanation of what the product actually does.

## 9. Keep placeholder artwork for now

Do not spend design time sourcing real/licensed artwork yet.

The current generated placeholders are sufficient for UX iteration. We
will replace them with stronger realistic artwork before external
organizer testing.

## Overall product principle

Please use this as the filter for all refinements:

> **The organizer should spend time choosing work they love---not
> correcting participants, managing rules, re-entering prompts, checking
> the same creator repeatedly, or doing administrative cleanup.**

Automation handles deterministic administration.

Participants are responsible for complying with the rules.

The organizer remains responsible for taste and final decisions.
